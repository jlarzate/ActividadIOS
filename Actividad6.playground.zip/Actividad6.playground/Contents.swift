import UIKit

//Potencia de a respecto a b
prefix operator |>

func |>(a:Int, f:(Int)->Int)-> Int{
    return f(a)
}
func potencia(x:Int) -> Int{
    return x ^ 2
}
2|>potencia
//Ordenar coleccion
        var cadena = [2,5,3,4]
func Orden (a:Int, cadena:Int) -> Bool {
    for valor in cadena {
            return a>valor
    }

}

// Subscript
let cantidades = [2,3,4,5]

class Cantidad{
    var valores:[Int]
    init (v:[Int])
    {
        self.valores = v
    }
    subscript(idx:Int) -> Int{
        get{
            return valores[idx]
        }
        set(nuevoValor){
            valores[idx] = nuevoValor
        }
    }
}
let v1 = Cantidad(v: cantidades)
v1[0] = v1[0]*2
v1[1] = v1[1]*2
v1[2] = v1[2]*2
v1[3] = v1[3]*2
v1.valores

//Control de error
let dictError = ["A":1,"B":2,"C":3]
func Existe (idx:String){
    guard let existe = dictError[idx]else {
        print ("No existe")
        return
    }
    print ("existe \(existe)")
}
Existe (idx:"A")
dictError["A"]
