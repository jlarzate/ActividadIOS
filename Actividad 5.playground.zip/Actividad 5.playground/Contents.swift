import UIKit

class Persona{
    var mensaje = "", pasos = ""
    var v1 = 0
    func Saludar(Nombre:String){
        self.mensaje = Nombre + "mucho gusto"
    }
    func Caminar(v1:Int){
        self.pasos = String(v1)
    }
}
struct Pantalla{
    var ancho:Int
    var alto:Int
    
    init(alto:Int, ancho:Int)
    {
    self.alto = alto
    self.ancho = ancho
    }
}

extension Int{
    var horas:Int{
        return self*60*60
    }
}
//horas a segundos
3.horas

extension String{
    var diaSemana:String{
        return self
    }
    func dia()->Int{
        var valor = 0
        if(diaSemana=="Domingo"){valor = 1}
        if(diaSemana=="Lunes"){valor = 2}
        if(diaSemana=="Martes"){valor = 3}
        if(diaSemana=="Miercoles"){valor = 4}
        if(diaSemana=="Jueves"){valor = 5}
        if(diaSemana=="Viernes"){valor = 6}
        if(diaSemana=="Sabado"){valor = 7}
        return valor
  }
}
"Domingo".dia()
//Optional
let dias = ["GDL":120, "PUE":300, "MTY":100, "CDMX":200]
var existe:Int?
//Aplicacion
existe = dias["DF"]

//Puente
if let temp = dias["DF"]{
    print("Si existe")
}
