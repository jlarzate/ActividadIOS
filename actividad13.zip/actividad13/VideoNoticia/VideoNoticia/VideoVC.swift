//
//  VideoVC.swift
//  VideoNoticia

import UIKit
import AVKit
import AVFoundation


class VideoVC: AVPlayerViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        let ligaVideo = "http://walterebert.com/playground/video/hls/sintel-trailer.m3u8"
        let urlVideo = URL(string: ligaVideo)
        
        if let urlVideo = urlVideo {
            let asset = AVAsset(url: urlVideo)
            let item = AVPlayerItem(asset: asset)
            let myPlayer = AVPlayer(playerItem: item)
            self.player = myPlayer
            myPlayer.play()
            
        }
    
        
        
        
        
    }

    
    

   }
