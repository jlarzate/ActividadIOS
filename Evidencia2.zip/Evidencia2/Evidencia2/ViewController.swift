//
//  ViewController.swift
//  Evidencia2
//
//  Created by user182630 on 4/14/21.
//  Copyright © 2021 user. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBAction func Image1(_ sender: Any) {
    }
    @IBAction func derecha1(_ sender: Any) {
        
    }
    @IBOutlet weak var imagen: UIImageView!
    override func viewDidLoad() {
    
        // Do any additional setup after loading the view.
    }


}

